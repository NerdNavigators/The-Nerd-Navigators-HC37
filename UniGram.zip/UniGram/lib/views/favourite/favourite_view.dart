import 'package:flutter/material.dart';

class FavouriteView extends StatelessWidget {
  const FavouriteView({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
    );
  }
}