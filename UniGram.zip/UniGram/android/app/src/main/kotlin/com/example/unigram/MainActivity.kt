package com.example.unigram

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
